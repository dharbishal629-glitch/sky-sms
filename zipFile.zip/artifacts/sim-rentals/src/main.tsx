import { createRoot } from "react-dom/client";
import { setBaseUrl } from "@workspace/api-client-react";
import { LanguageProvider } from "@/hooks/useLanguage";
import App from "./App";
import "./index.css";

const apiUrl = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/+$/, "");
if (apiUrl) {
  setBaseUrl(apiUrl);
}

createRoot(document.getElementById("root")!).render(
  <LanguageProvider>
    <App />
  </LanguageProvider>
);
